#include <stdio.h>
#include <stdlib.h>

void sumarNumero(int unNumero, int otroNumero);

int main()
{
    int numeroUno;
    int numeroDos;
    int resultado;
    printf("Ingrese un numero: ");
    scanf("%d", &numeroUno);
    printf("Ingrese otro numero: ");
    scanf("%d", &numeroDos);
    sumarNumero(numeroUno, numeroDos);

    return 0;
}

void sumarNumero(int unNumero, int otroNumero)
{

    int resultado;
    resultado = unNumero + otroNumero;
    printf("El resultado es: %d", resultado);


}
