#include <stdio.h>
#include <stdlib.h>

void (void);

int main()
{
    int resultado;
    resultado = void;
    return 0;
}
void (void)
{
    int numeroUno;
    int numeroDos;
    int resultado;
    printf("Ingrese un numero: ");
    scanf("%d", &numeroUno);
    printf("Ingrese otro numero: ");
    scanf("%d", &numeroDos);
    resultado = numeroUno + numeroDos;
    printf("La suma es: %d", resultado);
}
