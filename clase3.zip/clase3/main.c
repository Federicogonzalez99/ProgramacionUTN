#include <stdio.h>
#include <stdlib.h>

int sumarNumero(int unNumero, int otroNumero);

int main()
{
    int numeroUno;
    int numeroDos;
    int resultado;
    printf("Ingrese un numero: ");
    scanf("%d", &numeroUno);
    printf("Ingrese otro numero: ");
    scanf("%d", &numeroDos);

    resultado = sumarNumero(numeroUno, numeroDos);
    printf("El resultado es: %d", resultado);
    return 0;
}

int sumarNumero(int unNumero, int otroNumero)
{
    int resultado;
    resultado = unNumero + otroNumero;
    return resultado;
}
