#include <stdio.h>
#include <stdlib.h>

int sumar(void);

int main()
{
    int resultado;
    resultado = sumar();
    printf("La suma es: %d", resultado);

    return 0;
}
int sumar(void)
{
    int unNumero;
    int otroNumero;
    int resultado;
    printf("Ingrese un numero: ");
    scanf("%d", &unNumero);
    printf("Ingrese otro numero: ");
    scanf("%d", &otroNumero);
    resultado = unNumero + otroNumero;


    return resultado;
}
